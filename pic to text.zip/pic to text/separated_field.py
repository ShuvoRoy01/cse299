import re
import csv
from pypdf import PdfReader

pdf_path="jpg.pdf"
csv_path="updated_output.csv"
def extract_fields_from_pdf(pdf_path, csv_path):
    # Read the PDF file
    reader = PdfReader(pdf_path)
    all_text = ""
    for page in reader.pages:
        all_text += page.extract_text()

    # Use a regular expression to extract key-value pairs (e.g., "Name: John")
    field_pattern = r"(\w+):\s*([\w\s]+)"
    fields = re.findall(field_pattern, all_text)

    # Prepare data for CSV
    data = {}
    for field, value in fields:
        data[field] = value

    # Write to CSV
    with open(csv_path, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=data.keys())
        writer.writeheader()
        writer.writerow(data)


extract_fields_from_pdf(pdf_path, csv_path)
